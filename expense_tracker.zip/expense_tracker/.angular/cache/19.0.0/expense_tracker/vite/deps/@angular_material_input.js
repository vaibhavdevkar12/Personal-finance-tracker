import {
  MAT_INPUT_CONFIG,
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-R4YUP5QL.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-2GXLZF5X.js";
import "./chunk-CP7VMDSG.js";
import "./chunk-735BKUC6.js";
import "./chunk-7A77VJHU.js";
import "./chunk-BGHKUUNQ.js";
import "./chunk-QZC442CC.js";
import "./chunk-IMO4PGE6.js";
export {
  MAT_INPUT_CONFIG,
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
