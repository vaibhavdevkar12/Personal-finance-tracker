
import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiService } from '../api.service';
import { MaterialModule } from '../material/material.module';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';

export interface Transaction {
  id: number;
  date: Date;
  description: string;
  amount: number;
  type: string;
  createdOn: Date;
}

@Component({
  selector: 'app-maintenance',
  imports: [MaterialModule, ReactiveFormsModule],
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.scss'],
})
export class MaintenanceComponent implements OnInit {
  years: number[] = [];
  months: { index: number; name: string }[] = [];
  transactionForm!: FormGroup;
  dataSource = new MatTableDataSource<Transaction>();
  columns = ['id', 'date', 'description', 'amount', 'type', 'createdOn', 'delete'];

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private apiService: ApiService
  ) {
    const currentYear = new Date().getFullYear();
    for (let year = currentYear; year >= 2021; year--) {
      this.years.push(year);
    }

    this.months = [
      { index: 0, name: 'January' },
      { index: 1, name: 'February' },
      { index: 2, name: 'March' },
      { index: 3, name: 'April' },
      { index: 4, name: 'May' },
      { index: 5, name: 'June' },
      { index: 6, name: 'July' },
      { index: 7, name: 'August' },
      { index: 8, name: 'September' },
      { index: 9, name: 'October' },
      { index: 10, name: 'November' },
      { index: 11, name: 'December' },
    ];
  }

  ngOnInit(): void {
    this.transactionForm = this.fb.group({
      id: [0],
      year: [2024, Validators.required],
      month: [new Date().getMonth(), Validators.required],
      date: [null, Validators.required],
      description: ['', Validators.required],
      amount: [null, Validators.required],
      type: ['DEBIT', Validators.required],
    });
    this.getTransactions();
  }

  getTransactions() {
    this.dataSource.data = this.apiService.getAllTransactions();
  }

  insertForm() {
    const transaction: Transaction = this.prepareTransactionData();
    this.apiService.insertTransaction(transaction);
    this.resetForm();
    this.getTransactions();
  }

  updateform() {
    const transaction: Transaction = this.prepareTransactionData();
    this.apiService.updateTransaction(transaction);
    this.resetForm();
    this.getTransactions();
  }

  edit(transaction: Transaction) {
    this.transactionForm.setValue({
      id: transaction.id,
      year: new Date(transaction.date).getFullYear(),
      month: new Date(transaction.date).getMonth(),
      date: new Date(transaction.date).getDate(),
      description: transaction.description,
      amount: transaction.amount,
      type: transaction.type,
    });
  }

  deleteElement(transaction: Transaction) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Delete Confirmation',
        message: 'This will delete the transaction. Are you sure?',
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.apiService.deleteTransaction(transaction.id);
        this.getTransactions();
        this.snackBar.open('Transaction Deleted', 'OK', { duration: 3000 });
      }
    });
  }

  private prepareTransactionData(): Transaction {
    const formValues = this.transactionForm.value;
    return {
      id: formValues.id,
      date: new Date(
        formValues.year,
        formValues.month,
        formValues.date
      ),
      description: formValues.description,
      amount: formValues.amount,
      type: formValues.type,
      createdOn: new Date(),
    };
  }

  private resetForm() {
    this.transactionForm.reset({
      id: 0,
      year: new Date().getFullYear(),
      month: new Date().getMonth(),
      date: null,
      description: '',
      amount: null,
      type: 'DEBIT',
    });
  }
}

