
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MaterialModule } from '../material/material.module';
import { Transaction } from '../maintenance/maintenance.component';
import { MonthNamePipe } from '../month-name.pipe';
import { ApiService } from '../api.service';

export interface MonthlyTransactions {
  year: number;
  month: number;
  transactions: Transaction[];
}

@Component({
  selector: 'view-data',
  standalone: true,
  imports: [MaterialModule, MonthNamePipe],
  templateUrl: './view-data.component.html',
  styleUrls: ['./view-data.component.scss'],
})
export class ViewDataComponent implements OnInit {
  displayedColumns: string[] = ['year', 'month', 'earnings', 'expenditure', 'savings', 'actions'];
  dataSource = new MatTableDataSource<MonthlyTransactions>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.dataSource.data = this.apiService.getMonthlyTransactions();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  getEarnings(year: number, month: number) {
    const list = this.dataSource.data.filter((d) => d.year === year && d.month === month);
    if (list.length === 0) return 0;
    const earningsList = list[0].transactions.filter((t) => t.type === 'CREDIT');
    return earningsList.reduce((sum, e) => sum + Number(e.amount), 0);
  }

  getExpenditure(year: number, month: number) {
    const list = this.dataSource.data.filter((d) => d.year === year && d.month === month);
    if (list.length === 0) return 0;
    const expenditureList = list[0].transactions.filter((t) => t.type === 'DEBIT');
    return expenditureList.reduce((sum, e) => sum + Number(e.amount), 0);
  }

  getSavings(year: number, month: number): number {
    return (
      this.getEarnings(year, month) - 
      this.getExpenditure(year, month) + 
      this.getPreviousSavings(year, month)
    );
  }

  getPreviousSavings(year: number, month: number): number {
    const minYear = Math.min(...this.dataSource.data.map((d) => d.year));
    const minMonth = Math.min(...this.dataSource.data.filter((d) => d.year === minYear).map((d) => d.month));
    if (year === minYear && month === minMonth) return 0;
    const prevYearMonth = this.getPreviousYearMonth(year, month);
    return this.getSavings(prevYearMonth.year, prevYearMonth.month);
  }

  getPreviousYearMonth(year: number, month: number): { year: number; month: number } {
    return month > 0 ? { year, month: month - 1 } : { year: year - 1, month: 11 };
  }
}

