import { Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { ViewDataComponent } from './view-data/view-data.component';
import { GraphViewComponent } from './graph-view/graph-view.component';

export const routes: Routes = [
    { path: 'maintenance', component: MaintenanceComponent },
    { path: 'tableView', component: ViewDataComponent },
    { path: 'graphView', component: GraphViewComponent },
    { path: '', redirectTo: 'maintenance', pathMatch: 'full'},
    { path: '**', component: PageNotFoundComponent},
];
