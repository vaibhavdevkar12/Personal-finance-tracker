import { Component, OnInit, ViewChild } from '@angular/core';
import { MaterialModule } from '../material/material.module';
import { Transaction } from '../maintenance/maintenance.component';
import { ApiService } from '../api.service';
import { ChartConfiguration, ChartOptions } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-graph-view',
  standalone: true,
  imports: [MaterialModule, BaseChartDirective],
  templateUrl: './graph-view.component.html',
  styleUrl: './graph-view.component.scss',
})
export class GraphViewComponent implements OnInit {
  @ViewChild(BaseChartDirective) chart?: BaseChartDirective;

  public lineChartData: ChartConfiguration<'line'>['data'] = {
    labels: [],
    datasets: [
      {
        data: [],
        label: 'Earnings',
        fill: true,
        tension: 0.4,
        borderColor: 'green',
        backgroundColor: 'rgba(0, 255, 0, 0.2)',
      },
      {
        data: [],
        label: 'Expenditure',
        fill: true,
        tension: 0.4,
        borderColor: 'red',
        backgroundColor: 'rgba(255, 0, 0, 0.2)',
      },
    ],
  };

  public lineChartOptions: ChartOptions<'line'> = {
    maintainAspectRatio: false,
  };

  public lineChartLegend = true;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    const storedData = this.apiService.getAllTransactions();
    this.loadData(storedData);
  }

  loadData(storedData: Transaction[]) {
    const monthlyData: { [key: string]: { earnings: number; expenditure: number } } = {};

    storedData.forEach((transaction) => {
      const date = new Date(transaction.date);
      const monthKey = `${date.getFullYear()}-${date.getMonth() + 1}`; // Year-Month format
      const amount = transaction.amount;

      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { earnings: 0, expenditure: 0 };
      }

      if (transaction.type.toUpperCase() === 'CREDIT') {
        monthlyData[monthKey].earnings += amount;
      } else if (transaction.type.toUpperCase() === 'DEBIT') {
        monthlyData[monthKey].expenditure += amount;
      }
    });

    const labels: string[] = [];
    const earningsData: number[] = [];
    const expenditureData: number[] = [];

    // Sort month keys in chronological order
    Object.keys(monthlyData)
      .sort((a, b) => new Date(`${a}-01`).getTime() - new Date(`${b}-01`).getTime()) // Sort by date
      .forEach((monthKey) => {
        labels.push(this.getMonthNameFromMonthKey(monthKey));
        earningsData.push(monthlyData[monthKey].earnings);
        expenditureData.push(monthlyData[monthKey].expenditure);
      });

    this.lineChartData.labels = labels;
    this.lineChartData.datasets[0].data = earningsData;
    this.lineChartData.datasets[1].data = expenditureData;

    if (this.chart) {
      this.chart.update();
    }
  }

  getMonthNameFromMonthKey(monthKey: string): string {
    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    const [year, month] = monthKey.split('-');
    return `${monthNames[parseInt(month, 10) - 1]} ${year}`; // Include year for clarity
  }
}
