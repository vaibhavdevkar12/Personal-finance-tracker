import { Injectable } from '@angular/core';
import { Transaction } from './maintenance/maintenance.component';
import { MonthlyTransactions } from './view-data/view-data.component';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  baseUrl: string = 'https://localhost:7021/api/Transaction/';

  constructor() {
    // Initialize with data from localStorage if available
    const savedTransactions = localStorage.getItem('transactions');
    if (savedTransactions) {
      this.allTransaction = JSON.parse(savedTransactions);
    }
  }

  allTransaction: Transaction[] = [];

  insertTransaction(transaction: Transaction) {
    this.allTransaction.push(transaction);
    this.saveData();
  }

  updateTransaction(transaction: Transaction) {
    const index = this.allTransaction.findIndex(event => event.id === transaction.id);
    if (index !== -1) {
      this.allTransaction.splice(index, 1, transaction); // Replace the old item
      this.saveData();
    }
  }

  getAllTransactions() {
    return this.allTransaction;
  }

  deleteTransaction(id: number) {
    this.allTransaction = this.allTransaction.filter((v) => v.id !== id);
    this.saveData();
  }

  getMonthlyTransactions() {
    let monthlyTransactions: MonthlyTransactions[] = [];
    const groupedByYear = this.allTransaction.reduce((acc, item) => {
      const year = new Date(item.date).getFullYear();
      if (!acc[year]) {
        acc[year] = [];
      }
      acc[year].push(item);
      return acc;
    }, {} as Record<number, Transaction[]>);

    for (const key in groupedByYear) {
      if (groupedByYear.hasOwnProperty(key)) {
        const groupedByMonth = groupedByYear[key].reduce((acc, item) => {
          const month = new Date(item.date).getMonth();
          if (!acc[month]) {
            acc[month] = [];
          }
          acc[month].push(item);
          return acc;
        }, {} as Record<number, Transaction[]>);

        for (const month in groupedByMonth) {
          if (groupedByMonth.hasOwnProperty(month)) {
            monthlyTransactions.push({
              year: +key,
              month: +month,
              transactions: groupedByMonth[month],
            });
          }
        }
      }
    }

    return monthlyTransactions;
  }

  private saveData() {
    localStorage.setItem('transactions', JSON.stringify(this.allTransaction));
  }
}
