using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Entities
{
  public class MyEntity
  {
    public int Id { get; set; }

    public DateOnly Date { get; set; }
    public string Description { get; set; } = string.Empty;

    public int Amount { get; set; }

    public TransactionType Type { get; set; }

    public DateTime CreatedOn { get; set; }
  }


  public enum TransactionType
  {
    CREDIT, DEBIT
  }
}
