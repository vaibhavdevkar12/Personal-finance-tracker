using ClassLibrary1.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Transactions;

namespace ClassLibrary1
{
  public class Context(IConfiguration configuration) : DbContext
  {
    public IConfiguration Configuration { get; } = configuration;
    public DbSet<MyEntity> MyEntities { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
      optionsBuilder.UseSqlServer(Configuration.GetConnectionString("DB"));
    }
  }
}
